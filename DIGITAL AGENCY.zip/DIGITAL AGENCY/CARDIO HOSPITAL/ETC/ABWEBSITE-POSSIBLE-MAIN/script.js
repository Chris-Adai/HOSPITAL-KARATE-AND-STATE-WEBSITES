const navbar = document.querySelector('nav');
const navbarWidth = navbar.offsetWidth;
console.log(navbarWidth); // Outputs the width of the navbar in pixels